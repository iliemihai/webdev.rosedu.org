var WIDTH;
var HEIGHT;
var CTX;
var CANVAS;
var TOGGLE_ANIMATION = true;

var HEROES = [[],[]];
var TOWERS = [[],[]];
var MINIONS = [[],[]];
var FIREBALLS = [];
var DETONATED = [];
var HEROBASES = [];


var DEAD_MINIONS = [[],[]];
var DEAD_TOWERS = [[],[]];

var PLAYER_HERO;
var PLAYER_TEAM;
var PLAYER_NO;

var PLAYERS_PER_TEAM;
var PLAYER_SPAWN;


// var GLOBALS = {
//     "ceva": 13
// }

// exports.GLOBALS = GLOBALS;



